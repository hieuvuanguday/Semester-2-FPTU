package DTO;
public interface Role {
    public void createWorker();
}
